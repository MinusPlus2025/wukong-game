import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';
import type { EnemySpawnSpec } from '../data/ChaptersData';

export interface ActiveEnemy {
  spec: EnemySpawnSpec;
  root: THREE.Group;
  modelWrap: THREE.Group;
  telegraphRing: THREE.Mesh;
  sealRing: THREE.Mesh;
  hpBarWrap: HTMLDivElement;
  hpBarFill: HTMLDivElement;
  hp: number;
  maxHp: number;
  baseScale: number;
  phase2: boolean;
  frozenTimer: number;
  windUpTimer: number;
  attackCooldown: number;
  hitFlashTimer: number;
  staggerTimer: number;
  posture: number;
  maxPosture: number;
  brokenTimer: number;
  phase3: boolean;
  pattern: number;
  vel: THREE.Vector3;
  undulate: boolean;
  proceduralBoss: boolean;
  dragonUniforms: Array<{ value: number }>;
  dragonAttackUniforms: Array<{ value: number }>;
  dead: boolean;
  deathTimer: number;
  mixer: THREE.AnimationMixer | null;
  actions: THREE.AnimationAction[];
  activeClipIdx: number;
  idleClipIdx: number;
  attackClipIdx: number;
  moveClipIdx: number;
  deathClipIdx: number;
}

export interface EnemyHitPlayerEvent {
  enemy: ActiveEnemy;
  damage: number;
  enemyName: string;
  isBossSlam: boolean;
  pos: THREE.Vector3;
}

/**
 * Journey to the West Yaoguai & Boss AI State Machine:
 * - Loads Aholo Lux3D GLB bosses & minions with graceful procedural fallback
 * - Red ground telegraph circle before heavy attacks -> enables Shift Perfect Dodge Bullet-Time!
 * - [1] 定身术 Golden Immobilize Seal ("定") state
 * - [3] 芭蕉宝扇 Hurricane knockback + stun
 * - Boss 50% HP "法天象地" Phase-2 Enrage (scale surge, crimson aura, faster slam shockwaves)
 */
export class EnemyManager {
  public enemies: ActiveEnemy[] = [];
  private pending = new Set<Promise<void>>();
  private generation = 0;
  private breathFx: Array<{ mesh: THREE.Mesh; life: number }> = [];
  private hpOverlay: HTMLDivElement;

  constructor(private scene: THREE.Scene, private camera: THREE.PerspectiveCamera) {
    this.hpOverlay = document.createElement('div');
    this.hpOverlay.className = 'enemy-hp-layer';
    document.body.appendChild(this.hpOverlay);
  }

  public clearAll(): void {
    this.generation += 1;
    const mats = new Set<THREE.Material>();
    const geos = new Set<THREE.BufferGeometry>();
    const texs = new Set<THREE.Texture>();
    for (const e of this.enemies) {
      this.scene.remove(e.root);
      e.root.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (!mesh.isMesh) return;
        if (mesh.geometry && !geos.has(mesh.geometry)) { geos.add(mesh.geometry); mesh.geometry.dispose(); }
        const list = (Array.isArray(mesh.material) ? mesh.material : [mesh.material]) as THREE.Material[];
        for (const raw of list) {
          const mat = raw as THREE.MeshStandardMaterial;
          if (!mat || mats.has(mat)) continue; mats.add(mat);
          for (const key of ['map', 'normalMap', 'roughnessMap', 'metalnessMap', 'emissiveMap', 'alphaMap'] as const) {
            const tex = (mat as unknown as Record<string, THREE.Texture | null>)[key];
            if (tex && !texs.has(tex)) { texs.add(tex); tex.dispose(); }
          }
          mat.dispose();
        }
      });
      e.hpBarWrap.remove();
    }
    for (const fx of this.breathFx) { this.scene.remove(fx.mesh); fx.mesh.geometry.dispose(); (fx.mesh.material as THREE.Material).dispose(); }
    this.breathFx = [];
    this.enemies = [];
    this.pending.clear();
  }

  public async spawnChapterEnemies(
    specs: EnemySpawnSpec[],
    loader: GLTFLoader,
    terrainHeightFn: (x: number, z: number) => number
  ): Promise<void> {
    this.clearAll();

    const gen = this.generation;
    for (const spec of specs) {
      const root = new THREE.Group();
      const y = terrainHeightFn(spec.pos[0], spec.pos[1]);
      root.position.set(spec.pos[0], y, spec.pos[1]);

      const modelWrap = new THREE.Group();
      root.add(modelWrap);

      // Crimson attack telegraph ring on ground (warns player to press Shift!)
      const telegraphRadius = spec.isBoss ? 4.4 : 2.5;
      const telegraphRing = new THREE.Mesh(
        new THREE.RingGeometry(telegraphRadius * 0.62, telegraphRadius, 40),
        new THREE.MeshBasicMaterial({
          color: 0xff3b28,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0,
        })
      );
      telegraphRing.rotation.x = -Math.PI / 2;
      telegraphRing.position.y = 0.08;
      root.add(telegraphRing);

      // Golden Immobilize Seal ring ([1] 定身术)
      const sealRing = new THREE.Mesh(
        new THREE.TorusGeometry(spec.isBoss ? 1.9 : 1.05, 0.055, 12, 48),
        new THREE.MeshBasicMaterial({
          color: 0xffd966,
          transparent: true,
          opacity: 0,
        })
      );
      sealRing.rotation.x = Math.PI / 2;
      sealRing.position.y = spec.scale * 0.6;
      root.add(sealRing);

      // Floating HP bar for non-boss minions (Boss uses top-screen Grand Boss Bar)
      const hpBarWrap = document.createElement('div');
      hpBarWrap.className = `minion-hp ${spec.isBoss ? 'is-boss-hidden' : ''}`;
      hpBarWrap.innerHTML = `<span class="minion-name">${spec.name}</span><div class="minion-track"><div class="minion-fill"></div></div>`;
      const hpBarFill = hpBarWrap.querySelector('.minion-fill') as HTMLDivElement;
      this.hpOverlay.appendChild(hpBarWrap);

      this.scene.add(root);

      const enemy: ActiveEnemy = {
        spec,
        root,
        modelWrap,
        telegraphRing,
        sealRing,
        hpBarWrap,
        hpBarFill,
        hp: spec.hp,
        maxHp: spec.hp,
        baseScale: spec.scale,
        phase2: false,
        frozenTimer: 0,
        windUpTimer: 0,
        attackCooldown: 1.4 + Math.random() * 0.8,
        hitFlashTimer: 0,
        staggerTimer: 0,
        posture: 0,
        maxPosture: spec.isBoss ? 120 : 55,
        brokenTimer: 0,
        phase3: false,
        pattern: 0,
        vel: new THREE.Vector3(),
        undulate: false,
        proceduralBoss: false,
        dragonUniforms: [],
        dragonAttackUniforms: [],
        dead: false,
        deathTimer: 0,
        mixer: null,
        actions: [],
        activeClipIdx: -1,
        idleClipIdx: -1,
        attackClipIdx: -1,
        moveClipIdx: -1,
        deathClipIdx: -1,
      };
      this.enemies.push(enemy);

      // Load Aholo GLB asynchronously so chapter starts instantly
      this.pending.add(this.populateEnemyMesh(enemy, loader, gen));
    }
  }

  public async ready(): Promise<void> {
    await Promise.allSettled([...this.pending]);
  }

  private async populateEnemyMesh(enemy: ActiveEnemy, loader: GLTFLoader, gen: number): Promise<void> {
    const candidates = [...enemy.spec.modelCandidates, 'models/baize-beast.glb'];
    for (const url of candidates) {
      try {
        const head = await fetch(url, { method: 'HEAD' });
        if (!head.ok || (head.headers.get('content-type') || '').includes('text/html')) continue;
        const gltf = await loader.loadAsync(url);
        if (enemy.dead || gen !== this.generation) return;

        const m = SkeletonUtils.clone(gltf.scene);
        // Armature/empty nodes can inflate setFromObject massively. Measure visible mesh geometry only.
        m.updateMatrixWorld(true);
        const box = new THREE.Box3();
        const tb = new THREE.Box3();
        m.traverse((o) => {
          const mesh = o as THREE.Mesh;
          if (!mesh.isMesh || !mesh.geometry) return;
          mesh.geometry.computeBoundingBox();
          if (!mesh.geometry.boundingBox) return;
          tb.copy(mesh.geometry.boundingBox).applyMatrix4(mesh.matrixWorld);
          box.union(tb);
        });
        if (box.isEmpty()) box.setFromObject(m);
        const sz = new THREE.Vector3();
        const ctr = new THREE.Vector3();
        box.getSize(sz);
        box.getCenter(ctr);

        const maxDim = Math.max(0.01, sz.y, sz.x * 0.75);
        const s = enemy.spec.scale / maxDim;
        m.scale.setScalar(s);
        m.position.set(-ctr.x * s, -box.min.y * s, -ctr.z * s);
        m.traverse((obj) => {
          if ((obj as THREE.Mesh).isMesh) {
            obj.castShadow = true;
            obj.receiveShadow = true;
            obj.frustumCulled = false;
            const baseMat = (obj as THREE.Mesh).material as THREE.MeshStandardMaterial;
            if (baseMat) {
              baseMat.side = THREE.DoubleSide;
              baseMat.transparent = false;
              baseMat.opacity = 1;
              baseMat.alphaTest = 0;
              baseMat.depthWrite = true;
            }
            if (!enemy.spec.isBoss) {
              const mat = (obj as THREE.Mesh).material as THREE.MeshStandardMaterial;
              if (mat && mat.color) {
                const clone = mat.clone();
                clone.color.multiplyScalar(0.62);
                clone.emissive = new THREE.Color(0x1a0d08);
                clone.emissiveIntensity = 0.18;
                clone.transparent = false;
                clone.opacity = 1;
                clone.alphaTest = 0;
                clone.depthWrite = true;
                (obj as THREE.Mesh).material = clone;
              }
            }
          }
        });
        m.traverse((o) => { if ((o as THREE.Mesh).isMesh) { const mats = (Array.isArray((o as THREE.Mesh).material) ? (o as THREE.Mesh).material : [(o as THREE.Mesh).material]) as THREE.Material[]; for (const raw of mats) { const mat = raw as THREE.MeshStandardMaterial; if (mat?.map) { mat.map.anisotropy = 8; mat.map.needsUpdate = true; } } } });
        enemy.modelWrap.clear();
        enemy.modelWrap.add(m);

        if (gltf.animations && gltf.animations.length > 0) {
          enemy.mixer = new THREE.AnimationMixer(m);
          enemy.actions = gltf.animations.map((c) => enemy.mixer!.clipAction(c));
          const find = (re: RegExp) => gltf.animations.findIndex((c) => re.test(c.name));
          enemy.idleClipIdx = find(/idle/i);
          enemy.attackClipIdx = find(/headbutt|punch|bite|attack|claw|hit/i);
          enemy.moveClipIdx = find(/run|walk|fast_flying|flying/i);
          enemy.deathClipIdx = find(/death/i);
          this.playEnemyClip(enemy, enemy.idleClipIdx >= 0 ? enemy.idleClipIdx : 0);
        } else if (enemy.spec.isBoss) {
          enemy.proceduralBoss = true;
          if (enemy.spec.modelCandidates.some((u) => u.includes('zhulong'))) enemy.undulate = true;
          m.traverse((o) => {
            if (!(o as THREE.Mesh).isMesh) return;
            const mats = (Array.isArray((o as THREE.Mesh).material) ? (o as THREE.Mesh).material : [(o as THREE.Mesh).material]) as THREE.Material[];
            for (const raw of mats) {
              const mat = raw as THREE.MeshStandardMaterial;
              if (!mat || !mat.isMeshStandardMaterial) continue;
              const u = { value: 0 };
              const atk = { value: 0 };
              enemy.dragonUniforms.push(u);
              enemy.dragonAttackUniforms.push(atk);
              mat.onBeforeCompile = (shader) => {
                shader.uniforms.uDragonTime = u;
                shader.uniforms.uDragonAttack = atk;
                shader.vertexShader = 'uniform float uDragonTime;\nuniform float uDragonAttack;\n' + shader.vertexShader.replace(
                  '#include <begin_vertex>',
                  `#include <begin_vertex>
                   float wave = sin(position.y * 1.7 - uDragonTime * 2.2) * 0.10;
                   transformed.x += wave;
                   transformed.z += cos(position.y * 1.3 + uDragonTime * 1.6) * 0.08;
                   transformed.z += uDragonAttack * smoothstep(0.0, 0.9, position.y) * 0.45;`
                );
              };
              mat.needsUpdate = true;
            }
          });
        }
        return;
      } catch {
        // try next candidate
      }
    }

    // Immediate stylized demon sentinel fallback while GLB loads
    const mat = new THREE.MeshStandardMaterial({
      color: enemy.spec.color,
      roughness: 0.35,
      metalness: 0.55,
      emissive: enemy.spec.isBoss ? enemy.spec.color : 0x000000,
      emissiveIntensity: enemy.spec.isBoss ? 0.25 : 0,
    });
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.32 * enemy.spec.scale, 0.55 * enemy.spec.scale, 8, 16),
      mat
    );
    body.position.y = enemy.spec.scale * 0.55;
    body.castShadow = true;
    enemy.modelWrap.add(body);
  }

  private playEnemyClip(e: ActiveEnemy, idx: number): void {
    if (!e.mixer || e.actions.length === 0) return;
    const safe = Math.min(idx, e.actions.length - 1);
    if (e.activeClipIdx === safe) return;
    e.actions[safe].reset().fadeIn(0.16).play();
    if (e.activeClipIdx >= 0 && e.actions[e.activeClipIdx]) {
      e.actions[e.activeClipIdx].fadeOut(0.16);
    }
    e.activeClipIdx = safe;
  }

  public getAliveEnemies(): ActiveEnemy[] {
    return this.enemies.filter((e) => !e.dead);
  }

  public getActiveBoss(): ActiveEnemy | null {
    return this.enemies.find((e) => e.spec.isBoss && !e.dead) ?? null;
  }

  private spawnDragonBreath(e: ActiveEnemy): void {
    const fwd = new THREE.Vector3(Math.sin(e.root.rotation.y), 0, Math.cos(e.root.rotation.y));
    const geo = new THREE.CylinderGeometry(0.35, 4.2, 10, 20, 1, true);
    geo.rotateX(Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      color: 0xff6a1a, transparent: true, opacity: 0.55, side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending, depthWrite: false,
    });
    const cone = new THREE.Mesh(geo, mat);
    cone.position.copy(e.root.position).addScaledVector(fwd, 4.8);
    cone.position.y += 1.5;
    cone.rotation.y = e.root.rotation.y + Math.PI;
    this.scene.add(cone);
    this.breathFx.push({ mesh: cone, life: 0.45 });
  }

  public isAnyAttackImminentNear(pos: THREE.Vector3, radius = 6.2): boolean {
    for (const e of this.enemies) {
      if (e.dead || e.frozenTimer > 0) continue;
      if (e.windUpTimer > 0 && e.windUpTimer < 0.52) {
        if (e.root.position.distanceTo(pos) <= radius) return true;
      }
    }
    return false;
  }

  public applyDamage(enemy: ActiveEnemy, dmg: number, knockbackDir?: THREE.Vector3): boolean {
    if (enemy.dead) return false;
    enemy.hp = Math.max(0, enemy.hp - dmg);
    enemy.hitFlashTimer = 0.16;
    enemy.staggerTimer = Math.max(
      enemy.staggerTimer,
      enemy.spec.isBoss ? 0.07 : 0.18 + Math.min(0.28, dmg * 0.0018)
    );
    if (!enemy.spec.isBoss) {
      enemy.windUpTimer = 0;
      enemy.attackCooldown = Math.max(enemy.attackCooldown, 0.75);
      (enemy.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
    }

    if (knockbackDir && !enemy.spec.isBoss) {
      enemy.root.position.addScaledVector(knockbackDir, 0.85);
    } else if (knockbackDir && enemy.spec.isBoss) {
      enemy.root.position.addScaledVector(knockbackDir, 0.25);
    }

    // Boss 50% HP Phase-2 "法天象地" Enrage!
    if (enemy.spec.isBoss && !enemy.phase3 && enemy.hp > 0 && enemy.hp <= enemy.maxHp * 0.2) {
      enemy.phase3 = true;
      enemy.phase2 = true;
      enemy.modelWrap.scale.setScalar(1.36);
    }

    let triggeredPhase2 = false;
    if (enemy.spec.isBoss && !enemy.phase2 && enemy.hp > 0 && enemy.hp <= enemy.maxHp * 0.5) {
      enemy.phase2 = true;
      triggeredPhase2 = true;
      enemy.modelWrap.scale.setScalar(1.26);
    }

    if (enemy.hp <= 0) {
      enemy.dead = true;
      enemy.deathTimer = 1.2;
      if (enemy.deathClipIdx >= 0 && enemy.actions[enemy.deathClipIdx]) {
        enemy.actions.forEach((a) => a.stop());
        enemy.actions[enemy.deathClipIdx].reset().fadeIn(0.1).play();
        enemy.activeClipIdx = enemy.deathClipIdx;
      }
      (enemy.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
      (enemy.sealRing.material as THREE.MeshBasicMaterial).opacity = 0;
      enemy.hpBarWrap.style.opacity = '0';
    }
    return triggeredPhase2;
  }

  public addPosture(enemy: ActiveEnemy, amount: number): boolean {
    if (enemy.dead || enemy.brokenTimer > 0) return false;
    enemy.posture = Math.min(enemy.maxPosture, enemy.posture + amount);
    if (enemy.posture >= enemy.maxPosture) {
      enemy.posture = 0;
      enemy.brokenTimer = enemy.spec.isBoss ? 1.2 : 1.6;
      enemy.staggerTimer = Math.max(enemy.staggerTimer, enemy.brokenTimer);
      enemy.windUpTimer = 0;
      (enemy.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
      return true;
    }
    return false;
  }

  public castDingShen(origin: THREE.Vector3, range = 14): number {
    let count = 0;
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (e.root.position.distanceTo(origin) <= range) {
        e.frozenTimer = e.spec.isBoss ? 3.8 : 5.2;
        e.windUpTimer = 0;
        (e.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
        (e.sealRing.material as THREE.MeshBasicMaterial).opacity = 0.95;
        count++;
      }
    }
    return count;
  }

  public castPlantainHurricane(origin: THREE.Vector3, forward: THREE.Vector3): number {
    let hitCount = 0;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const toEnemy = e.root.position.clone().sub(origin);
      const dist = toEnemy.length();
      if (dist <= 18) {
        const pushDir = toEnemy.lengthSq() > 0.01 ? toEnemy.normalize() : forward.clone();
        e.root.position.addScaledVector(pushDir, e.spec.isBoss ? 4.2 : 8.5);
        e.windUpTimer = 0;
        e.attackCooldown = 1.6;
        this.applyDamage(e, e.spec.isBoss ? 68 : 95);
        hitCount++;
      }
    }
    return hitCount;
  }

  public update(
    dt: number,
    playerPos: THREE.Vector3,
    terrainHeightFn: (x: number, z: number) => number,
    onHitPlayer: (ev: EnemyHitPlayerEvent) => void,
    resolveCollision?: (pos: THREE.Vector3) => void
  ): boolean {
    let anyAggro = false;

    for (const e of this.enemies) {
      if (e.dead) {
        if (e.deathTimer > 0) {
          e.deathTimer -= dt;
          if (e.mixer) e.mixer.update(dt * 0.9);
          if (e.deathClipIdx < 0) {
            e.modelWrap.scale.multiplyScalar(0.9);
            e.root.position.y -= dt * 1.4;
          } else if (e.deathTimer < 0.35) {
            e.root.position.y -= dt * 0.8;
          }
          if (e.deathTimer <= 0) {
            this.scene.remove(e.root);
            e.hpBarWrap.remove();
          }
        }
        continue;
      }

      if (e.proceduralBoss && e.actions.length === 0) {
        const pt = performance.now() * 0.001;
        const breathe = 1 + Math.sin(pt * 1.35 + e.spec.scale) * 0.018;
        e.modelWrap.scale.setScalar((e.phase2 ? 1.36 : 1) * breathe);
        e.modelWrap.rotation.z = Math.sin(pt * 0.9) * 0.012;
        if (e.windUpTimer > 0) {
          e.modelWrap.rotation.x = -0.10 - Math.sin((1 - e.windUpTimer) * Math.PI) * 0.14;
        } else {
          e.modelWrap.rotation.x = 0;
        }
      }
      if (e.undulate && e.dragonUniforms.length > 0) {
        const t = performance.now() * 0.001;
        for (const u of e.dragonUniforms) u.value = t;
        for (const a of e.dragonAttackUniforms) a.value = e.windUpTimer > 0 ? Math.min(1, (1.1 - e.windUpTimer) / 0.5) : 0;
        e.modelWrap.position.y = Math.sin(t * 1.2) * 0.15;
      }
      if (e.actions.length > 0 && e.spec.name.includes('龙')) {
        const dtSway = performance.now() * 0.001;
        e.modelWrap.rotation.y = Math.sin(dtSway * 0.9) * 0.48;
        e.modelWrap.rotation.z = Math.sin(dtSway * 1.35) * 0.12;
        e.modelWrap.position.y = Math.sin(dtSway * 1.7) * 0.32;
      }
      if (e.mixer && e.frozenTimer <= 0) {
        e.mixer.update(dt * (e.phase3 ? 1.55 : e.phase2 ? 1.35 : 1.0));
      }

      // Hit recoil pulse
      if (e.hitFlashTimer > 0) {
        e.hitFlashTimer -= dt;
        const targetS = e.phase2 ? 1.34 : 1.08;
        e.modelWrap.scale.setScalar(targetS);
      } else {
        const restS = e.phase2 ? 1.26 : 1.0;
        e.modelWrap.scale.lerp(new THREE.Vector3(restS, restS, restS), dt * 8);
      }

      // Immobilized by [1] 定身术
      if (e.frozenTimer > 0) {
        e.frozenTimer -= dt;
        e.sealRing.rotation.z += dt * 2.8;
        (e.sealRing.material as THREE.MeshBasicMaterial).opacity = Math.min(0.95, e.frozenTimer);
        this.updateFloatingBar(e);
        continue;
      } else {
        (e.sealRing.material as THREE.MeshBasicMaterial).opacity = 0;
      }

      if (e.brokenTimer > 0) {
        e.brokenTimer = Math.max(0, e.brokenTimer - dt);
        e.modelWrap.rotation.z = Math.sin(performance.now() * 0.03) * 0.06;
      } else {
        e.modelWrap.rotation.z = 0;
        e.posture = Math.max(0, e.posture - dt * 3.5);
      }

      if (e.staggerTimer > 0) {
        e.staggerTimer -= dt;
        e.modelWrap.position.x = Math.sin(performance.now() * 0.09) * 0.045;
        this.updateFloatingBar(e);
        continue;
      } else {
        e.modelWrap.position.x = 0;
      }

      const toPlayer = new THREE.Vector3(
        playerPos.x - e.root.position.x,
        0,
        playerPos.z - e.root.position.z
      );
      const dist = toPlayer.length();
      const aggroRadius = e.spec.isBoss ? 26 : 17;
      const atkRange = e.spec.isBoss ? 4.3 : 2.55;

      if (dist < aggroRadius) {
        anyAggro = true;
        const desiredYaw = Math.atan2(toPlayer.x, toPlayer.z);
        e.root.rotation.y = THREE.MathUtils.lerp(e.root.rotation.y, desiredYaw, dt * 6);

        if (e.windUpTimer > 0) {
          e.vel.multiplyScalar(Math.max(0, 1 - dt * 10));
          this.playEnemyClip(e, e.attackClipIdx >= 0 ? e.attackClipIdx : e.phase2 ? 3 : 2);
          e.windUpTimer -= dt;
          const pulse = 0.42 + Math.abs(Math.sin(performance.now() * 0.02)) * 0.45;
          (e.telegraphRing.material as THREE.MeshBasicMaterial).opacity = pulse;
          e.telegraphRing.scale.setScalar(e.spec.isBoss ? (e.pattern === 2 ? 1.7 : e.pattern === 1 ? 1.25 : 1) : 1);
          e.modelWrap.position.y = Math.sin((1 - e.windUpTimer) * Math.PI) * (e.spec.isBoss ? 1.15 : 0.45);

          if (e.windUpTimer <= 0) {
            // Execute strike!
            e.modelWrap.position.y = 0;
            (e.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;
            e.attackCooldown = e.phase2 ? 1.35 : e.spec.isBoss ? 2.1 : 1.85;

            const isBoss = e.spec.isBoss;
            let hitRadius = isBoss ? (e.phase2 ? 5.2 : 4.5) : 2.75;
            let isSlam = isBoss;
            if (isBoss && e.pattern === 1) {
              // Charge: close the gap before the hit.
              const chargeDir = new THREE.Vector3(playerPos.x - e.root.position.x, 0, playerPos.z - e.root.position.z).normalize();
              e.root.position.addScaledVector(chargeDir, 3.2);
              hitRadius = 3.4;
              isSlam = true;
            } else if (isBoss && e.pattern === 2) {
              // Ground shockwave: larger, slower hit.
              hitRadius = 7.4;
              isSlam = true;
            }
            if (isBoss && e.spec.name.includes('龙') && e.pattern === 2) {
              // Dragon breath: forward cone instead of a circular shockwave.
              this.spawnDragonBreath(e);
              const fwd = new THREE.Vector3(Math.sin(e.root.rotation.y), 0, Math.cos(e.root.rotation.y));
              const to = new THREE.Vector3(playerPos.x - e.root.position.x, 0, playerPos.z - e.root.position.z);
              const breathDist = to.length();
              const inCone = breathDist < 10 && (breathDist < 0.1 || to.normalize().dot(fwd) > 0.42);
              if (inCone) {
                onHitPlayer({
                  damage: Math.round(e.spec.atk * (e.phase3 ? 1.8 : 1.45)),
                  enemyName: e.spec.name,
                  isBossSlam: true,
                  enemy: e,
                  pos: e.root.position.clone(),
                });
              }
            } else {
              const currentDist = e.root.position.distanceTo(playerPos);
              if (currentDist <= hitRadius) {
                onHitPlayer({
                  damage: e.phase3 ? Math.round(e.spec.atk * 1.65) : e.phase2 ? Math.round(e.spec.atk * 1.35) : e.spec.atk,
                  enemyName: e.spec.name,
                  isBossSlam: isSlam,
                  enemy: e,
                  pos: e.root.position.clone(),
                });
              }
            }
          }
        } else {
          e.attackCooldown = Math.max(0, e.attackCooldown - dt);
          const moveSpd = (e.spec.isBoss ? 4.4 : 4.9) * (e.phase3 ? 1.55 : e.phase2 ? 1.3 : 1.0);
          const wantsMove = dist > atkRange * 0.85;
          const desired = wantsMove ? toPlayer.clone().normalize().multiplyScalar(moveSpd) : new THREE.Vector3();
          const accel = wantsMove ? 6.5 : 10;
          e.vel.x += (desired.x - e.vel.x) * Math.min(1, dt * accel);
          e.vel.z += (desired.z - e.vel.z) * Math.min(1, dt * accel);
          if (!wantsMove) e.vel.multiplyScalar(Math.max(0, 1 - dt * 7));
          e.root.position.addScaledVector(e.vel, dt);
          resolveCollision?.(e.root.position);

          // Keep individual enemies from stacking into one body.
          for (const other of this.enemies) {
            if (other === e || other.dead) continue;
            const ox = e.root.position.x - other.root.position.x;
            const oz = e.root.position.z - other.root.position.z;
            const min = (e.spec.scale + other.spec.scale) * 0.55;
            const d2 = ox * ox + oz * oz;
            if (d2 > 0.0001 && d2 < min * min) {
              const d = Math.sqrt(d2);
              e.root.position.x += (ox / d) * (min - d) * 0.35;
              e.root.position.z += (oz / d) * (min - d) * 0.35;
            }
          }

          if (e.vel.lengthSq() > 0.025) {
            if (e.actions.length > 0) {
              this.playEnemyClip(e, e.moveClipIdx >= 0 ? e.moveClipIdx : 1);
              const act = e.actions[e.activeClipIdx];
              if (act) act.timeScale = THREE.MathUtils.clamp(e.vel.length() / moveSpd, 0.6, 1.35);
              e.modelWrap.position.y = 0;
            } else {
              // Static Lux3D minion: no skeleton. Lean and sway instead of fake hopping.
              e.modelWrap.rotation.x = -0.09;
              e.modelWrap.rotation.z = Math.sin(performance.now() * 0.008) * 0.035;
              e.modelWrap.position.y = 0;
            }
          } else if (dist <= atkRange && e.attackCooldown <= 0) {
            // Start telegraphed wind-up so player can dodge or counter!
            if (e.spec.isBoss) {
              e.pattern = (e.pattern + 1) % 3;
              e.windUpTimer = [e.phase2 ? 0.68 : 0.9, 0.5, 1.15][e.pattern];
            } else {
              e.windUpTimer = 0.65;
            }
          } else {
            this.playEnemyClip(e, e.idleClipIdx >= 0 ? e.idleClipIdx : 0);
            e.modelWrap.rotation.x = 0;
            e.modelWrap.rotation.z = 0;
            e.modelWrap.position.y = 0;
            const act = e.actions[e.activeClipIdx];
            if (act) act.timeScale = 1;
          }
        }
      } else {
        this.playEnemyClip(e, e.idleClipIdx >= 0 ? e.idleClipIdx : 0);
      }

      e.root.position.x = THREE.MathUtils.clamp(e.root.position.x, -32, 32);
      e.root.position.z = THREE.MathUtils.clamp(e.root.position.z, -32, 28);
      e.root.position.y = terrainHeightFn(e.root.position.x, e.root.position.z);

      this.updateFloatingBar(e);
    }

    return anyAggro;
  }

  private updateFloatingBar(e: ActiveEnemy): void {
    if (e.spec.isBoss) return;
    const headPos = e.root.position.clone().add(new THREE.Vector3(0, e.spec.scale * 1.15 + 0.5, 0));
    const proj = headPos.project(this.camera);
    if (proj.z > 1) {
      e.hpBarWrap.style.display = 'none';
      return;
    }
    e.hpBarWrap.style.display = 'block';
    const x = (proj.x * 0.5 + 0.5) * window.innerWidth;
    const y = (-proj.y * 0.5 + 0.5) * window.innerHeight;
    e.hpBarWrap.style.left = `${x}px`;
    e.hpBarWrap.style.top = `${y}px`;
    e.hpBarFill.style.width = `${Math.max(0, (e.hp / e.maxHp) * 100)}%`;
  }
}
